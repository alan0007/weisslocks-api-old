Nodejs firebase in 4 step


## 1- Creating an Firebase application
Creating an Firebase application by a click on https://console.firebase.google.com/
![alt text](https://cdn-images-1.medium.com/max/1760/1*Fbx6FGGiFiq5iAKe6Od1Eg.png)

2- Get service account key
After you click the Generate New Private Key button, a JSON file containing your service account’s credentials will be downloaded. You’ll need this to initialize the SDK in the next step.
To read more: https://firebase.google.com/docs/admin/setup

![alt text](https://cdn-images-1.medium.com/max/1760/1*1aRZ-Z32fyG6zv4zpvcZAw.png)

3- Setup Node.js project
Setting up Node.js application for Firebase project is easy,  

![alt text](https://cdn-images-1.medium.com/max/1800/1*EK0xtWM8s7ymdNtqQt-9Og.png)





Reference:
 — https://firebase.google.com/docs/admin/setup
    <!-- Footer -->
    <!--<footer class="site-footer">
      <div class="site-footer-legal">© 2018 <a href="http://themeforest.net/item/remark-responsive-bootstrap-admin-template/11989202">Remark</a></div>
      <div class="site-footer-right">
        Crafted with <i class="red-600 wb wb-heart"></i> by <a href="http://themeforest.net/user/amazingSurge">amazingSurge</a>
      </div>
    </footer>-->
    
    <!-- jQuery Version 1.11.0 -->
    <!--  <script src="js/jquery-1.11.0.js"></script>-->

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>
    <script src="js/bootstrap-datetimepicker.min.js"></script>
    <!-- Core  -->
    <script src="js/babel-external-helpers.js"></script>
    <!--<script src="js/jquery.js"></script>-->
    <script src="js/popper.min.js"></script>
    <!--<script src="js/bootstrap.js"></script>-->
    <script src="js/animsition.js"></script>
    <script src="js/jquery.mousewheel.js"></script>
    <script src="js/jquery-asScrollbar.js"></script>
    <script src="js/jquery-asScrollable.js"></script>
    <script src="js/jquery-asHoverScroll.js"></script>
    
    <!-- Plugins -->
    <script src="js/switchery.js"></script>
    <script src="js/intro.js"></script>
    <script src="js/screenfull.js"></script>
    <script src="js/jquery-slidePanel.js"></script>
    <script src="js/skycons.js"></script>
    <script src="js/chartist.min.js"></script>
    <script src="js/chartist-plugin-tooltip.js"></script>
    <script src="js/jquery-asPieProgress.min.js"></script>
    <script src="js/jquery-jvectormap.min.js"></script>
    <script src="js/jquery-jvectormap-au-mill-en.js"></script>
    <script src="js/jquery.matchHeight-min.js"></script>
    <!-- Scripts -->
    <script src="js/Component.js"></script>
    <script src="js/Plugin.js"></script>
    <script src="js/Base.js"></script>
    <script src="js/Config.js"></script>
    <script src="js/Menubar.js"></script>
    <script src="js/GridMenu.js"></script>
    <script src="js/Sidebar.js"></script>
    <script src="js/PageAside.js"></script>
    <script src="js/menu.js"></script>
    <script src="js/colors.js"></script>
    <script src="js/tour.js"></script>
    <script>Config.set('assets', '../assets');</script>
    <!-- Page -->
    <script src="js/Site.js"></script>
    <script src="js/asscrollable.js"></script>
    <script src="js/slidepanel.js"></script>
    <script src="js/switchery.js"></script>
    <script src="js/matchheight.js"></script>
    <script src="js/jvectormap.js"></script>
    <!--<script src="js/v1.js"></script>-->
	
	<!-- Script to make content height equal to Side Bar Menu -->
	<script>
		
	</script>
	
</body>
</html>